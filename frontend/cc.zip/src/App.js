import logo from './logo.svg';
import './App.css';
import LanguageConverter from './LanguageConverter';

function App() {
  return (
    <div className="App">
     
      <LanguageConverter />
    </div>
  );
}

export default App;
